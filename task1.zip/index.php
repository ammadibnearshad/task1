<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Paratemporal Night Vision Equipment For Paranormal Investigations</title>
<style type="text/css">
<!--
body {
	background-color: #121212;
	margin-left: 0px;
	margin-top: 0px;
}
-->
</style>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body onload="MM_preloadImages('report2.gif','skywatchad.jpg')">
<table width="768" border="0" align="center" cellpadding="0" cellspacing="0">
  
  <tr>
    <td height="450" bgcolor="#121212"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="swflash.cab" width="768" height="560">
      <param name="movie" value="paratemporal_main.swf" />
      <param name="quality" value="high" />
      <param name="menu" value="false" />
      <embed src="paratemporal_main.swf" width="768" height="560" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" menu="false"></embed>
    </object></td>
  </tr>
  <tr>
    <td height="10" align="center" valign="top" bgcolor="#000000"></td>
  </tr>
  <tr>
    <td height="150" align="center" valign="bottom" bgcolor="#000000"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td align="center" valign="top"><a href="report.html" target="_self" onmouseover="MM_swapImage('report','','report2.gif',1)" onmouseout="MM_swapImgRestore()"><img src="report.gif" alt="Read The Paratemporal Operational Report" name="report" width="500" height="60" border="0" id="report" /></a><a href="skywatch.html" target="_self" onmouseover="MM_swapImage('Sky Watching Events','','skywatchad.jpg',1)" onmouseout="MM_swapImgRestore()"><br />
<img src="skywatchad_light.jpg" alt="Sky Watching Events" name="Sky Watching Events" width="500" height="180" border="0" id="Sky Watching Events" /></a></td>
          <td width="250" align="right"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="245" height="245">
            <param name="movie" value="mp3player.swf" />
            <param name="quality" value="high" />
            <param name="menu" value="false" />
            <embed src="mp3player.swf" width="245" height="245" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" menu="false"></embed>
          </object>
          <br /></td>
        </tr>
      </table>
      <p align="right">&nbsp;</p>
      <p><font color="#006600" size="2" face="Arial, Helvetica, sans-serif">Website Designed By Paranormal-investigation.com<br />
        All Rights Reserved | Copyright © 2009
        <script language="JavaScript">
var d=new Date(); 
yr=d.getFullYear();
if (yr!=2009)
document.write("- "+yr+" ");

          </script> 
        Shadowbox Enterprises, LLC
        </font><br />
        <br />
      </p></td>
  </tr>
</table>
</body>
</html>
